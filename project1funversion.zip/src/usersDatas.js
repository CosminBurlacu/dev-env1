const users = [
    {
        name:"Cosmin Burlacu",
        age:22,
        image:"./image/cosminburlacu.jpg",
        skills:[
            {
                skillName:"JavaScript",
                skillPercentage:80
            },
            {
                skillName:"React",
                skillPercentage:70
            },
            {
                skillName:"Redux",
                skillPercentage:65
            },
            {
                skillName:"CSS3",
                skillPercentage:95
            },
            {
                skillName:"SASS",
                skillPercentage:90
            },
            {
                skillName:"HTML5",
                skillPercentage:95
            },
            {
                skillName:"Jest",
                skillPercentage:85
            },
            {
                skillName:"Enzyme",
                skillPercentage:80
            },
            {
                skillName:"Webpack",
                skillPercentage:70
            }
        ],
        description:"My name is Cosmin Burlacu and I am a FrontEnd Developer",
        id:1
    },
    {
        name:"Anders Latif",
        age:22,
        image:"./image/user2.jpg",
        skills:[
            {
                skillName:"JavaScript2",
                skillPercentage:90
            },
            {
                skillName:"Redux2",
                skillPercentage:70
            }
        ],
        description:"My name is Cosmin Burlacu2",
        id:2
    }
];
export default users;